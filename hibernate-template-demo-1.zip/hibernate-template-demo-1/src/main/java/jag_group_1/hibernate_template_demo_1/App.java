package jag_group_1.hibernate_template_demo_1;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Product;
import model.ProductDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
    	ProductDao pdao= (ProductDao) ctx.getBean("pdao");
//    	int id=pdao.create(new Product("Pencil", 10f));
//    	System.out.println(id);
//    	Product product = pdao.read(1);
//    	product.setName("Sharpner");
//    	pdao.update(product);
//    	System.out.println(product);
    	pdao.delete(1);
    	List<Product> products = pdao.read();
    	for(Product p:products)
    		System.out.println(p);
    	
        System.out.println( "Hello World!" );
    }
}
