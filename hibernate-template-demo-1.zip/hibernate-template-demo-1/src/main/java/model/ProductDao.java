package model;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class ProductDao {
	private HibernateTemplate ht;
	public ProductDao() {}
	public ProductDao(HibernateTemplate ht) {
		super();
		this.ht = ht;
	}
	public HibernateTemplate getHt() {
		return ht;
	}
	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	@Transactional
	public Integer create(Product product)
	{
		Integer id=(Integer) ht.save(product);
		return id;
	}
	public List<Product> read()
	{
		return ht.loadAll(Product.class);
	}
	public Product read(Integer id)
	{
		return ht.get(Product.class, id);
	}
	@Transactional
	public void update(Product product)
	{
		ht.update(product);
	}
	@Transactional
	public void delete(Integer id)
	{
		ht.delete(read(id));
	}
}
